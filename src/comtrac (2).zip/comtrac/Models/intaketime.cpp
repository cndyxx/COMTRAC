
#include "intaketime.h"

IntakeTime::IntakeTime(QObject *parent)
    : QObject{parent}
{

}

