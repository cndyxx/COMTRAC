
#include "user.h"

User::User(QObject *parent)
    : QObject{parent}
{

}

